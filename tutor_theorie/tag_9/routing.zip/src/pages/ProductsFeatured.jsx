
function ProductsFeatured() {
  return (
    <div>ProductsFeatured</div>
  )
}

export default ProductsFeatured