import React from 'react'

function ProductsIndex() {
  return (
    <div>ProductsIndex</div>
  )
}

export default ProductsIndex