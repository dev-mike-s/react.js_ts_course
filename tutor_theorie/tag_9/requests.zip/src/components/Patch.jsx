import React from 'react'

function Patch() {
  return (
    <div>Patch</div>
  )
}

export default Patch